﻿namespace WindowsFormsApp9
{
    partial class CarCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CarCalc));
            this.DebtBox = new System.Windows.Forms.ListBox();
            this.btnAddDebt = new System.Windows.Forms.Button();
            this.txtDname = new System.Windows.Forms.TextBox();
            this.txtDcost = new System.Windows.Forms.TextBox();
            this.btnDelDebt = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblOut = new System.Windows.Forms.Label();
            this.txtIncome = new System.Windows.Forms.TextBox();
            this.grpDebt = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rdoGood = new System.Windows.Forms.RadioButton();
            this.rdoBad = new System.Windows.Forms.RadioButton();
            this.rdoOk = new System.Windows.Forms.RadioButton();
            this.grpCredit = new System.Windows.Forms.GroupBox();
            this.lblCredit = new System.Windows.Forms.Label();
            this.txtYears = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.grpDebt.SuspendLayout();
            this.grpCredit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DebtBox
            // 
            this.DebtBox.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DebtBox.FormattingEnabled = true;
            this.DebtBox.ItemHeight = 14;
            this.DebtBox.Location = new System.Drawing.Point(6, 19);
            this.DebtBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DebtBox.Name = "DebtBox";
            this.DebtBox.Size = new System.Drawing.Size(277, 88);
            this.DebtBox.TabIndex = 0;
            this.DebtBox.SelectedIndexChanged += new System.EventHandler(this.DebtBox_SelectedIndexChanged);
            // 
            // btnAddDebt
            // 
            this.btnAddDebt.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnAddDebt.Location = new System.Drawing.Point(6, 159);
            this.btnAddDebt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddDebt.Name = "btnAddDebt";
            this.btnAddDebt.Size = new System.Drawing.Size(87, 56);
            this.btnAddDebt.TabIndex = 2;
            this.btnAddDebt.Text = "Add Monthly Payment";
            this.btnAddDebt.UseVisualStyleBackColor = true;
            this.btnAddDebt.Click += new System.EventHandler(this.btnAddDebt_Click);
            // 
            // txtDname
            // 
            this.txtDname.Location = new System.Drawing.Point(6, 131);
            this.txtDname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDname.Name = "txtDname";
            this.txtDname.Size = new System.Drawing.Size(179, 20);
            this.txtDname.TabIndex = 0;
            // 
            // txtDcost
            // 
            this.txtDcost.Location = new System.Drawing.Point(193, 131);
            this.txtDcost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDcost.Name = "txtDcost";
            this.txtDcost.Size = new System.Drawing.Size(89, 20);
            this.txtDcost.TabIndex = 1;
            // 
            // btnDelDebt
            // 
            this.btnDelDebt.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnDelDebt.Location = new System.Drawing.Point(99, 159);
            this.btnDelDebt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDelDebt.Name = "btnDelDebt";
            this.btnDelDebt.Size = new System.Drawing.Size(183, 24);
            this.btnDelDebt.TabIndex = 4;
            this.btnDelDebt.Text = "Delete Selected Payment";
            this.btnDelDebt.UseVisualStyleBackColor = true;
            this.btnDelDebt.Click += new System.EventHandler(this.btnDelDebt_Click);
            // 
            // btnClear
            // 
            this.btnClear.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnClear.Location = new System.Drawing.Point(99, 191);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(183, 24);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear All Payments";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 14);
            this.label1.TabIndex = 6;
            this.label1.Text = "Payment Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(192, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 14);
            this.label2.TabIndex = 7;
            this.label2.Text = "Payment Cost";
            // 
            // lblOut
            // 
            this.lblOut.Location = new System.Drawing.Point(306, 296);
            this.lblOut.Name = "lblOut";
            this.lblOut.Size = new System.Drawing.Size(294, 37);
            this.lblOut.TabIndex = 9;
            // 
            // txtIncome
            // 
            this.txtIncome.Location = new System.Drawing.Point(310, 238);
            this.txtIncome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtIncome.Name = "txtIncome";
            this.txtIncome.Size = new System.Drawing.Size(127, 20);
            this.txtIncome.TabIndex = 2;
            this.txtIncome.Text = "0.0";
            this.txtIncome.TextChanged += new System.EventHandler(this.txtIncome_TextChanged);
            // 
            // grpDebt
            // 
            this.grpDebt.Controls.Add(this.DebtBox);
            this.grpDebt.Controls.Add(this.btnAddDebt);
            this.grpDebt.Controls.Add(this.txtDname);
            this.grpDebt.Controls.Add(this.txtDcost);
            this.grpDebt.Controls.Add(this.label2);
            this.grpDebt.Controls.Add(this.btnDelDebt);
            this.grpDebt.Controls.Add(this.label1);
            this.grpDebt.Controls.Add(this.btnClear);
            this.grpDebt.Location = new System.Drawing.Point(12, 107);
            this.grpDebt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpDebt.Name = "grpDebt";
            this.grpDebt.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpDebt.Size = new System.Drawing.Size(291, 226);
            this.grpDebt.TabIndex = 0;
            this.grpDebt.TabStop = false;
            this.grpDebt.Text = "Add your monthly payments";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(307, 220);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 14);
            this.label3.TabIndex = 12;
            this.label3.Text = "Montly Income";
            // 
            // rdoGood
            // 
            this.rdoGood.AutoSize = true;
            this.rdoGood.Location = new System.Drawing.Point(6, 19);
            this.rdoGood.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdoGood.Name = "rdoGood";
            this.rdoGood.Size = new System.Drawing.Size(53, 18);
            this.rdoGood.TabIndex = 0;
            this.rdoGood.TabStop = true;
            this.rdoGood.Text = "Good";
            this.rdoGood.UseVisualStyleBackColor = true;
            this.rdoGood.CheckedChanged += new System.EventHandler(this.rdoGood_CheckedChanged);
            // 
            // rdoBad
            // 
            this.rdoBad.AutoSize = true;
            this.rdoBad.Location = new System.Drawing.Point(6, 66);
            this.rdoBad.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdoBad.Name = "rdoBad";
            this.rdoBad.Size = new System.Drawing.Size(46, 18);
            this.rdoBad.TabIndex = 2;
            this.rdoBad.TabStop = true;
            this.rdoBad.Text = "Bad";
            this.rdoBad.UseVisualStyleBackColor = true;
            this.rdoBad.CheckedChanged += new System.EventHandler(this.rdoBad_CheckedChanged);
            // 
            // rdoOk
            // 
            this.rdoOk.AutoSize = true;
            this.rdoOk.Location = new System.Drawing.Point(6, 44);
            this.rdoOk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdoOk.Name = "rdoOk";
            this.rdoOk.Size = new System.Drawing.Size(39, 18);
            this.rdoOk.TabIndex = 1;
            this.rdoOk.TabStop = true;
            this.rdoOk.Text = "Ok";
            this.rdoOk.UseVisualStyleBackColor = true;
            this.rdoOk.CheckedChanged += new System.EventHandler(this.rdoOk_CheckedChanged);
            // 
            // grpCredit
            // 
            this.grpCredit.Controls.Add(this.lblCredit);
            this.grpCredit.Controls.Add(this.rdoBad);
            this.grpCredit.Controls.Add(this.rdoOk);
            this.grpCredit.Controls.Add(this.rdoGood);
            this.grpCredit.Location = new System.Drawing.Point(309, 107);
            this.grpCredit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpCredit.Name = "grpCredit";
            this.grpCredit.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpCredit.Size = new System.Drawing.Size(291, 94);
            this.grpCredit.TabIndex = 1;
            this.grpCredit.TabStop = false;
            this.grpCredit.Text = "Select a credit score";
            // 
            // lblCredit
            // 
            this.lblCredit.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCredit.Location = new System.Drawing.Point(96, 19);
            this.lblCredit.Name = "lblCredit";
            this.lblCredit.Size = new System.Drawing.Size(185, 65);
            this.lblCredit.TabIndex = 16;
            this.lblCredit.Text = "Estemated Interest Rate 8.0% ";
            this.lblCredit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtYears
            // 
            this.txtYears.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtYears.Location = new System.Drawing.Point(443, 238);
            this.txtYears.Name = "txtYears";
            this.txtYears.Size = new System.Drawing.Size(157, 20);
            this.txtYears.TabIndex = 3;
            this.txtYears.Text = "0.0";
            this.txtYears.TextChanged += new System.EventHandler(this.txtYears_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(440, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 14);
            this.label4.TabIndex = 18;
            this.label4.Text = "Years For Loan";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(28, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(130, 104);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Courier New", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(14, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(379, 66);
            this.label5.TabIndex = 20;
            this.label5.Text = "Bozo Auto";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-28, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(683, 104);
            this.panel1.TabIndex = 21;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(183, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(383, 83);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "                                                                                 " +
    "        ";
            // 
            // CarCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Brown;
            this.ClientSize = new System.Drawing.Size(601, 345);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtYears);
            this.Controls.Add(this.grpCredit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.grpDebt);
            this.Controls.Add(this.txtIncome);
            this.Controls.Add(this.lblOut);
            this.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "CarCalc";
            this.Text = "Car Payment Calculator";
            this.Load += new System.EventHandler(this.CarCalc_Load);
            this.grpDebt.ResumeLayout(false);
            this.grpDebt.PerformLayout();
            this.grpCredit.ResumeLayout(false);
            this.grpCredit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox DebtBox;
        private System.Windows.Forms.Button btnAddDebt;
        private System.Windows.Forms.TextBox txtDname;
        private System.Windows.Forms.TextBox txtDcost;
        private System.Windows.Forms.Button btnDelDebt;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblOut;
        private System.Windows.Forms.TextBox txtIncome;
        private System.Windows.Forms.GroupBox grpDebt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdoGood;
        private System.Windows.Forms.RadioButton rdoBad;
        private System.Windows.Forms.RadioButton rdoOk;
        private System.Windows.Forms.GroupBox grpCredit;
        private System.Windows.Forms.Label lblCredit;
        private System.Windows.Forms.TextBox txtYears;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

