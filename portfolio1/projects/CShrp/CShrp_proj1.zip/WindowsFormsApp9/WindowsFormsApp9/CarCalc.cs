﻿using System;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp9
{
    public partial class CarCalc : Form
    {
        public CarCalc()
        {
            InitializeComponent();
            rdoGood.Select();
            //Couldn't find \n in the visual view so we set it in code
            lblOut.Text = "Allowable Payment: $0.00\nMax Car Value: $0.00";

        }

        #region form level vars
        //users interest rate based on radio button selection
        decimal interest = .08m;
        //the montly income of the user
        decimal cost = 0m;
        //the number of years that the user wants to take out a loan
        decimal years = 0m; 
        //this is where we store the monthly payments of the user
        /*(we store them here as apposed to the list in the listbox becuse we 
         * can more easily retrive and enforce the datatype of the list)*/
        List<Tuple<string, decimal>> debtPriceList = new List<Tuple<string, decimal>> { };
        #endregion

        #region custom functions

        /*
         * this region contains functions that are only used in this form inside of C#s form control event functions
         * and are designed to be roughly re-usable in other programs (with the exception of outputCost)
         * 
         * NOTE: the event functions are in the next region
         */

        private void OutputCost()
        { 

            /*
             * this function outputs the maximum cost and allowed payment to the lbloutput
             * using variables set on the form level
             * 
             */
            decimal allowedPay = getMaxVal(cost, debtPriceList);
            if (allowedPay < 0)
            {
                //they cannot pay anything to us within their monthly payments
                lblOut.Text = "Sorry, you have too many mothly payments";
            }
            else
            {
                //NOTE: as far as the program is concernd leap years do NOT exist
                //I should have checked ahead to make sure that this function took decimals :/
                
                try
                {
                    //Im not entirly sure how the PV function works. and I dont quite trust it so it can go in the try
                    //catch box just in case it gets buggy (plus error handling is required for the assignment)

                    double maxTotal = Financial.PV((double)(interest / 12m), (double)years * 12, (double)allowedPay) * -1;
                    //display that cost to the output label
                    lblOut.Text = "Allowable Payment: " + allowedPay.ToString("C2") + "\n";
                    lblOut.Text += "Max Car Value: " + maxTotal.ToString("C2");
                }
                catch
                {
                    lblOut.Text = "ERROR: PV function failed!";
                }

                
            }

        }

        decimal getMaxVal(decimal Income, List<Tuple<string,decimal>> costs)
        {


            /*
             * this function gets the maximum payment a user can make based on their income and debts
             * 
             * desing notes:
             *      This could be turned into a sum function if we wanted to REALLY generalize it, but theres no need
             *      plus we can technicaly increase efficientcy by returning -1 as SOON as maxDebt is less than zero, as apposed to summing
             *      all of the negative debts up
             */



            decimal maxDebt = Income * .36m;
            foreach (Tuple<string,decimal> costt in costs)
            {
                //subtract the stored cost from the maxDebt
                maxDebt -= costt.Item2;
                //return -1 if they have too much debt
                if (maxDebt < 0) { return -1; }
            }
            return maxDebt;
        }
        
        bool fillLbLBox(ListBox DebtBox,List<Tuple<string,decimal>> debts)
        {
            /*
             *   this function is used with the DebtBox label box to format the text outputed to it
             *   such that all of the : will be on the same line
             *   
             *   NOTE: this function will ONLY work when the label box is using a monospace font 
             *   (as the function assumes that each letter of the font takes up the same space)
             */

            DebtBox.Items.Clear(); // clear out the previous formating

//get the max length of the strings
            int maxL = 0;
            foreach (Tuple<string, decimal> t in debts)
            {
                //have the lengths of the strings "fight" so we get the largest length use that to fromat the box
                if (t.Item1.Length > maxL){ maxL = t.Item1.Length; }
            }

//use the max length to format the output
            foreach (Tuple<string, decimal> t in debts)
            {
                //store the tuple string in a "buffer" so we can modify it
                string output = t.Item1;
                //make sure that each of the names has the same length
                while (output.Length < maxL)
                {
                    output += " ";
                }
                output += " :" + t.Item2.ToString("C2"); // append the cost of the debt and a seperator to the output
                DebtBox.Items.Add(output);
            }
            return true;
        }
        #endregion

        #region event functions
        /*
         * this region contains functions that fire becuse of a form control event
         */

        #region debts
            /*
             * this region contains the code that operates the debt box
             * and maintains the debtPriceList list
             */
        private void btnDelDebt_Click(object sender, EventArgs e)
        {
            if (DebtBox.SelectedIndex >= 0)
            {
                //remove corisponding debtPriceList entry, then update the list box
                debtPriceList.RemoveAt(DebtBox.SelectedIndex);
            }
            //update the label box entries
            fillLbLBox(DebtBox,debtPriceList);

            OutputCost();
        }

        private void btnAddDebt_Click(object sender, EventArgs e)
        {
            //we need to add the items to our internal storage vector, then update the lblBox
            decimal cost;
            decimal.TryParse(txtDcost.Text, out cost);
            var T = Tuple.Create<string, decimal>(txtDname.Text, cost);
            debtPriceList.Add(T);
            fillLbLBox(DebtBox,debtPriceList);
            OutputCost();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //its faster to clear the debtBox than use the for loops to do the formating if we know nothings there
            DebtBox.Items.Clear();
            //remove every item from the debt list when the user asks to clear it
            debtPriceList.Clear();

            OutputCost();
        }
        #endregion //every thing to do with the debt box

        #region interest radio buttons
        /*
         * this region contains all of the code running the radio buttons
         * and setting up the interest variable
         */
        void setInterestBox(decimal credit)
        {
            //this function is here to set the lblCredit text (and help us change all three at the same time for updating)
            lblCredit.Text = "Estemated Interest Rate\n" + credit.ToString("P1");
        }
        
            /*
             * NOTE: we COULD use a switch statement and check the value of each of them on calc time, but we have to update
             * the lblCredit box on checkchanged any ways, so we may as well save the interest
            */ 
        private void rdoGood_CheckedChanged(object sender, EventArgs e)
        { 
            interest = .08m;
            setInterestBox(interest);
            OutputCost();
        }
        private void rdoOk_CheckedChanged(object sender, EventArgs e)
        {
            interest = .16m;
            setInterestBox(interest);
            OutputCost();
        }
        private void rdoBad_CheckedChanged(object sender, EventArgs e)
        {
            interest = .19m;
            setInterestBox(interest);
            OutputCost();
        }
        #endregion 

        #region txt input (income and years) 
        /*
         * this region contains all of the code that 
         * deals with getting income and year input
         */
        private void txtIncome_TextChanged(object sender, EventArgs e)
        {
            //update the cost variable
            decimal.TryParse(txtIncome.Text, out cost);
            OutputCost();
        }
        private void txtYears_TextChanged(object sender, EventArgs e)
        {
            //update the years variables
            decimal.TryParse(txtYears.Text, out years);
            OutputCost();
        }
        #endregion // 

        #region irritating functions
        /*
         * this region contains functions that do nothing but make the program error when deleted
         * I would very much like to know how to remove them
        */
        private void btnCalc_Click(object sender, EventArgs e)
        {
            OutputCost();
        }

        private void CarCalc_Load(object sender, EventArgs e)
        {

        }

        private void DebtBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        #endregion
        #endregion

    }
}
